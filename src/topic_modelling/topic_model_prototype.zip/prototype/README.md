For topic modelling of the research summarises and description.
