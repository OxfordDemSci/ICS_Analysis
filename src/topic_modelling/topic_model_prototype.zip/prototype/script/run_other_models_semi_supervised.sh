python3 BERT_other_model_variants_semi_supervised.py "./data/subset/non_shape.csv" "BERT_non_SHAPE_semi_supervised" "Summary impact type";
python3 BERT_other_model_variants_semi_supervised.py "./data/subset/panel_d.csv" "BERT_panel_D_semi_supervised" "Summary impact type";
python3 BERT_other_model_variants_semi_supervised.py "./data/subset/panel_c.csv" "BERT_panel_C_semi_supervised" "Summary impact type";
python3 BERT_other_model_variants_semi_supervised.py "./data/clean_ref_ics_data_cleaned_lemmatized_sample.csv" "BERT_SHAPE_semi_supervised" "Summary impact type";
python3 BERT_other_model_variants_semi_supervised.py "./data/clean_ref_ics_data_lemmatized_full.csv" "BERT_full_semi_supervised" "Summary impact type";
